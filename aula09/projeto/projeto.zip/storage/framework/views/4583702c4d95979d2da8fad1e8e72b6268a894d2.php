;

<?php $__env->startSection('principal'); ?>
<h1>Novo Produto</h1>


<form action="<?php echo e(route('produtos.store')); ?>" method="POST">

  <?php echo csrf_field(); ?>
  Nome: <input type="text" name="nome"> <br>
  Estoque: <input type="number" name="estoque" id=""><br>
  Preco: <input type="number" min="0" step="any" name="preco"><br>
  Marca: 
  <select name="marca_id">
      <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($m->id); ?>"><?php echo e($m->nome); ?></option>      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
  </select><br>

  <div style="display: flex; flex-direction:row;">
    <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div style="margin-right: 10px; margin-top: 5px; margin-bottom: 20px">        
        <?php echo e($d->nome); ?>

        <input type="checkbox" name="departamentos[]" value="<?php echo e($d->id); ?>">
      </div>      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

  <input type="submit" value="Salvar">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web\aula09\projeto\resources\views/produtos/create.blade.php ENDPATH**/ ?>