<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Inicio</title>
</head>
<body>
    <h1>Página Inicial</h1>
    <div>
        <a href="/clientes">Clientes</a><br><br>
        <a href="/departamentos">Departamentos</a><br><br>
        <a href="/marcas">Marcas</a>
        <a href="/produtos">Produtos</a>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Web\aula09\projeto\resources\views/welcome.blade.php ENDPATH**/ ?>